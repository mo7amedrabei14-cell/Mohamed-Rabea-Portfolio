import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ECHO-style motion: everything after the intro. Content lives in App.jsx.
export function startEcho() {
  if (reduced()) return () => {};
  const root = document.documentElement;
  const mm = gsap.matchMedia();
  const off = [];
  const contact = document.querySelector('.ec-contact');
  const hero = document.querySelector('.hero');
  const dir = () => (root.dir === 'rtl' ? -1 : 1);

  const onSheen = (e) => {
    const r = contact.getBoundingClientRect();
    contact.style.setProperty('--ec-x', `${Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100))}%`);
  };
  contact?.addEventListener('pointermove', onSheen, { passive: true });

  const ctx = gsap.context(() => {
    // Hero: the ID badge drops on its lanyard once the intro opens, then swings with the pointer.
    const introOn = root.classList.contains('hz-intro');
    if (introOn) gsap.set(['.ec-badge', '.ec-hero-cta'], { opacity: 0 });
    let entered = false;
    const enter = () => {
      if (entered) return;
      entered = true;
      gsap.fromTo('.ec-badge', { y: -170, rotation: -7, opacity: 1 }, { y: 0, rotation: 0, duration: 2.1, ease: 'elastic.out(1, 0.42)' });
      gsap.fromTo('.ec-hero-cta', { y: 24, opacity: 0 }, { y: 0, opacity: 1, duration: 1, ease: 'expo.out', delay: 0.5 });
    };
    if (!introOn) enter();
    window.addEventListener('ec-intro-reveal', enter);
    window.addEventListener('ec-intro-done', enter);
    const safety = setTimeout(enter, 24000);
    off.push(() => { window.removeEventListener('ec-intro-reveal', enter); window.removeEventListener('ec-intro-done', enter); clearTimeout(safety); });
    const settle = new MutationObserver(() => { if (!root.classList.contains('hz-intro')) setTimeout(() => ScrollTrigger.refresh(), 120); });
    settle.observe(root, { attributes: true, attributeFilter: ['class'] });
    off.push(() => settle.disconnect());

    if (hero && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
      gsap.set('.ec-badge', { transformOrigin: '50% 0%' });
      const swing = gsap.quickTo('.ec-badge', 'rotation', { duration: 1.8, ease: 'elastic.out(1, 0.3)' });
      const move = (e) => swing((e.clientX / window.innerWidth - 0.5) * 12);
      hero.addEventListener('pointermove', move, { passive: true });
      off.push(() => hero.removeEventListener('pointermove', move));
    }

    // Sections open like a card on scroll.
    ['.ec-about', '.ec-work', '.ec-tools', '.ec-contact'].forEach((sel) => {
      const el = document.querySelector(sel);
      if (!el) return;
      gsap.fromTo(el, { clipPath: 'inset(8% 4% 0% 4% round 44px)' }, {
        clipPath: 'inset(0% 0% 0% 0% round 0px)', ease: 'none',
        scrollTrigger: { trigger: el, start: 'top 98%', end: 'top 40%', scrub: true },
      });
    });

    // Ghost text drifting behind the experience section.
    gsap.utils.toArray('.ec-ghost').forEach((el) => {
      gsap.fromTo(el.firstElementChild, { xPercent: 0 }, {
        xPercent: -34, ease: 'none',
        scrollTrigger: { trigger: el.closest('section'), start: 'top bottom', end: 'bottom top', scrub: true },
      });
    });

    // RGB split on giant headings that follows scroll velocity.
    const o = { v: 0 };
    const setSplit = () => { root.style.setProperty('--ec-split', `${o.v.toFixed(2)}px`); root.style.setProperty('--ec-a', Math.min(0.7, o.v / 2).toFixed(2)); };
    ScrollTrigger.create({
      onUpdate: (s) => {
        o.v = Math.min(5, Math.abs(s.getVelocity()) / 600);
        setSplit();
        gsap.to(o, { v: 0, duration: 0.6, overwrite: true, onUpdate: setSplit });
      },
    });

    // Ending: noise resolves into one straight red signal as the contact section arrives.
    const line = document.querySelector('.ec-signal-line');
    if (line && contact) {
      const N = 90;
      const seed = Array.from({ length: N + 1 }, (_, i) => (Math.sin(i * 12.9898) * 43758.5453) % 1);
      const draw = (p) => {
        const amp = (1 - p) * (1 - p) * 46;
        let pts = '';
        for (let i = 0; i <= N; i += 1) {
          const n = Math.sin(i * 1.7 + p * 6) * 0.6 + seed[i] * 0.8;
          pts += `${((i / N) * 1200).toFixed(1)},${(60 + n * amp).toFixed(1)} `;
        }
        line.setAttribute('points', pts.trim());
      };
      draw(0);
      ScrollTrigger.create({ trigger: contact, start: 'top 85%', end: 'top 12%', scrub: true, onUpdate: (st) => draw(st.progress), onRefresh: (st) => draw(st.progress) });
    }

    // Desktop pinned scenes, created in page order so their spacers measure correctly.
    mm.add('(min-width: 861px)', () => {
      // 1. Curved project reel
      const reel = document.querySelector('.ec-reel');
      if (reel) {
        const cards = gsap.utils.toArray('.ec-card', reel);
        const count = reel.querySelector('.ec-count b');
        const bar = reel.querySelector('.ec-bar i');
        const n = cards.length;
        const place = (t) => {
          cards.forEach((c, i) => {
            const d = i - t; const a = Math.abs(d);
            gsap.set(c, { xPercent: -50, x: d * dir() * window.innerWidth * 0.33, z: -a * 240, rotationY: -d * dir() * 34, scale: 1 - Math.min(a, 2) * 0.1, opacity: 1 - Math.min(a, 2) * 0.4, zIndex: 10 - Math.round(a * 2) });
          });
          if (count) count.textContent = String(Math.min(n, Math.round(t) + 1)).padStart(2, '0');
          if (bar) bar.style.transform = `scaleX(${n > 1 ? t / (n - 1) : 1})`;
        };
        place(0);
        ScrollTrigger.create({ trigger: reel, start: 'top top', end: () => `+=${window.innerHeight * (n - 1) * 0.9}`, pin: true, refreshPriority: 10, invalidateOnRefresh: true, onUpdate: (s) => place(s.progress * (n - 1)), onRefresh: (s) => place(s.progress * (n - 1)) });
      }
      // 2. Hexagonal toolkit ring
      const stage = document.querySelector('.ec-ring-stage');
      if (stage) {
        const ring = stage.querySelector('.ec-ring');
        const count = stage.querySelector('.ec-count b');
        const spin = (p) => {
          gsap.set(ring, { rotationY: -p * 300 * dir() });
          if (count) count.textContent = String(Math.min(6, Math.round(p * 5) + 1)).padStart(2, '0');
        };
        spin(0);
        ScrollTrigger.create({ trigger: stage, start: 'top top', end: () => `+=${window.innerHeight * 3}`, pin: true, refreshPriority: 9, invalidateOnRefresh: true, onUpdate: (s) => spin(s.progress), onRefresh: (s) => spin(s.progress) });
      }
      // 3. Horizontal experience track
      const pin = document.querySelector('.ec-exp-pin');
      const track = pin?.querySelector('.ec-track');
      if (pin && track) {
        const dist = () => Math.max(0, track.scrollWidth - window.innerWidth + 80);
        const slide = (p) => gsap.set(track, { x: -dist() * p * dir() });
        ScrollTrigger.create({ trigger: pin, start: 'top top', end: () => `+=${dist()}`, pin: true, refreshPriority: 8, invalidateOnRefresh: true, onUpdate: (s) => slide(s.progress), onRefresh: (s) => slide(s.progress) });
      }
      return undefined;
    });
  });

  // Layout shifts while the intro and fonts settle, so re-measure afterwards.
  const refresh = () => ScrollTrigger.refresh();
  const timers = [0, 600, 2000, 4500].map((ms) => setTimeout(refresh, ms));
  window.addEventListener('load', refresh);
  document.fonts?.ready.then(refresh);

  return () => {
    timers.forEach(clearTimeout);
    window.removeEventListener('load', refresh);
    contact?.removeEventListener('pointermove', onSheen);
    off.forEach((f) => f());
    mm.revert();
    ctx.revert();
    root.style.removeProperty('--ec-split');
    root.style.removeProperty('--ec-a');
  };
}
