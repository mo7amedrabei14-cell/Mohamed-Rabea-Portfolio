// Published Power BI reports (public links supplied by Mohamed).
// Nothing here is invented: `title` is a WORKING title taken from the image file name — edit it freely.
// `img` is the file name inside /public/images WITHOUT extension (the UI tries .png, .jpg, .jpeg, .webp).
// Leave `img` empty and a neutral "preview pending" tile is shown instead of a broken image.
export const powerBiReports = [
  {
    id: 'pbi-1',
    title: 'Psy supp',
    img: 'Psy supp',
    url: 'https://app.powerbi.com/view?r=eyJrIjoiMTY5NTAxOGMtMThlZC00MzJjLWFkYjctMWFjZjA1N2MyMGMyIiwidCI6IjAyNjU5ODhhLWU0MDQtNGRkYy1hMmEwLTY2MjUwNWMzYjc4ZiIsImMiOjh9',
  },
  {
    id: 'pbi-2',
    title: 'Rise in water',
    img: 'rise in water',
    url: 'https://app.powerbi.com/view?r=eyJrIjoiNWE0NTUwNmYtZWQ3MC00OTFhLTg3OTctZWM4MzVlY2UwNmVkIiwidCI6IjAyNjU5ODhhLWU0MDQtNGRkYy1hMmEwLTY2MjUwNWMzYjc4ZiIsImMiOjh9',
  },
  {
    id: 'pbi-3',
    title: 'Sanbsa',
    img: 'sanbsa',
    url: 'https://app.powerbi.com/view?r=eyJrIjoiYmUyZDVhMGUtOWVlZS00ZmEyLTg1YWMtOThkNmU0M2E4ZTNhIiwidCI6IjAyNjU5ODhhLWU0MDQtNGRkYy1hMmEwLTY2MjUwNWMzYjc4ZiIsImMiOjh9',
  },
];
