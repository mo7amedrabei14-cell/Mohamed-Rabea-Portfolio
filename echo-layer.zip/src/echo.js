import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ECHO-style layer: section "card" openings, ghost text, scroll RGB-split,
// a curved 3D project reel, and a metallic LET'S TALK. Content stays in App.jsx.
export function startEcho() {
  if (reduced()) return () => {};
  const root = document.documentElement;
  const mm = gsap.matchMedia();
  const contact = document.querySelector('.hz-contact');
  const onMove = (e) => {
    const r = contact.getBoundingClientRect();
    contact.style.setProperty('--ec-x', `${Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100))}%`);
  };

  const ctx = gsap.context(() => {
    // 1. Sections open like a card: clip-path grows to full bleed on scroll.
    ['.hz-man', '.hz-cap', '.hz-contact'].forEach((sel) => {
      const el = document.querySelector(sel);
      if (!el) return;
      gsap.fromTo(el, { clipPath: 'inset(9% 5% 0% 5% round 44px)' }, {
        clipPath: 'inset(0% 0% 0% 0% round 0px)', ease: 'none',
        scrollTrigger: { trigger: el, start: 'top 96%', end: 'top 32%', scrub: true },
      });
    });

    // 2. Ghost text drifting sideways behind the experience section.
    gsap.utils.toArray('.ec-ghost').forEach((el, i) => {
      gsap.fromTo(el.firstElementChild, { xPercent: i % 2 ? -34 : 0 }, {
        xPercent: i % 2 ? 0 : -34, ease: 'none',
        scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: true },
      });
    });

    // 3. RGB split on headings and ghost text that follows scroll velocity.
    const o = { v: 0 };
    ScrollTrigger.create({
      onUpdate: (s) => {
        o.v = Math.min(4, Math.abs(s.getVelocity()) / 700);
        gsap.to(o, { v: 0, duration: 0.6, overwrite: true, onUpdate: () => { root.style.setProperty('--ec-split', `${o.v.toFixed(2)}px`); root.style.setProperty('--ec-a', Math.min(0.7, o.v / 2).toFixed(2)); } });
        root.style.setProperty('--ec-split', `${o.v.toFixed(2)}px`);
        root.style.setProperty('--ec-a', Math.min(0.7, o.v / 2).toFixed(2));
      },
    });

    // 4. Metallic LET'S TALK: sheen follows the pointer.
    contact?.addEventListener('pointermove', onMove, { passive: true });

    // 5. Curved project reel (desktop): cards sit on an arc and turn with scroll.
    mm.add('(min-width: 861px)', () => {
      const reel = document.querySelector('.ec-reel');
      if (!reel) return undefined;
      const cards = gsap.utils.toArray('.ec-card', reel);
      const count = reel.querySelector('.ec-count b');
      const bar = reel.querySelector('.ec-bar i');
      const n = cards.length;
      const dir = () => (root.dir === 'rtl' ? -1 : 1);
      const place = (t) => {
        cards.forEach((c, i) => {
          const d = i - t;
          const a = Math.abs(d);
          gsap.set(c, {
            xPercent: -50, x: d * dir() * window.innerWidth * 0.33, z: -a * 240,
            rotationY: -d * dir() * 34, scale: 1 - Math.min(a, 2) * 0.1,
            opacity: 1 - Math.min(a, 2) * 0.4, zIndex: 10 - Math.round(a * 2),
          });
        });
        if (count) count.textContent = String(Math.min(n, Math.round(t) + 1)).padStart(2, '0');
        if (bar) bar.style.transform = `scaleX(${n > 1 ? t / (n - 1) : 1})`;
      };
      place(0);
      ScrollTrigger.create({
        trigger: reel, start: 'top top', end: () => `+=${window.innerHeight * (n - 1) * 0.9}`,
        pin: true, refreshPriority: 10, invalidateOnRefresh: true,
        onUpdate: (s) => place(s.progress * (n - 1)),
        onRefresh: (s) => place(s.progress * (n - 1)),
      });
      return undefined;
    });
  });

  // Layout shifts while the intro/fonts settle, so re-measure the pin afterwards.
  const refresh = () => ScrollTrigger.refresh();
  const timers = [0, 600, 2000, 4500].map((ms) => setTimeout(refresh, ms));
  const watch = new MutationObserver(() => { if (!root.classList.contains('hz-intro')) setTimeout(refresh, 120); });
  watch.observe(root, { attributes: true, attributeFilter: ['class'] });
  window.addEventListener('load', refresh);
  document.fonts?.ready.then(refresh);

  return () => {
    contact?.removeEventListener('pointermove', onMove);
    timers.forEach(clearTimeout);
    watch.disconnect();
    window.removeEventListener('load', refresh);
    mm.revert();
    ctx.revert();
    root.style.removeProperty('--ec-split');
    root.style.removeProperty('--ec-a');
  };
}
